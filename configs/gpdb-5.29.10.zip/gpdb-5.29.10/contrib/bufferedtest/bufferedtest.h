/*-------------------------------------------------------------------------
 *
 * bufferedtest.h
 *		Test the BufferedAppend (cdbbufferedappend.c and .h) and
 *      BufferedRead (cdbbufferedread.c and .h) modules.
 *
 * $PostgreSQL$
 *
 *-------------------------------------------------------------------------
 */

